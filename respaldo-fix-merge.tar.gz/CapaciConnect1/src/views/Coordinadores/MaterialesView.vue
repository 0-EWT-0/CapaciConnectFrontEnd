<template>
    <NavbarCoord />
    <div class="ml-[25rem]">
      <h1 class="text-black">Materiales</h1>

      <div class="bg-white shadow-lg rounded-lg h-[20rem] w-[20rem] m-10 p-5">
        <h2 class="text-black text-center">Titulo de Taller</h2>
        <p class="bg-gray-300 text-sm text-center"> Contenido Taller</p>
      </div>
    </div>
</template>

<script setup lang="ts">
import NavbarCoord from '@/components/global/Coordinador/NavbarCoord.vue'
</script>
