<template>
  <footer class="flex justify-center items-center px-19 py-4 bg-[#040273]">
    <!--  -->
    <div class="flex items-center space-x-4">
      <img src="@/assets/imgs/capacityLogo.png" class="w-13 h-13" />
      <h2 class="text-white">Capacity</h2>
    </div>
    <!--  -->
  </footer>
</template>
